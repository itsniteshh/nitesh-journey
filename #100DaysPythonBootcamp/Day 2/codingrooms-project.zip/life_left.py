# 🚨 Don't change the code below 👇
age = input("What is your current age? ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
ages_left = 90 - int(age)

days_left = ages_left * 365
weeks_left = ages_left * 53
months_left = ages_left * 12


print(f"you have {days_left} days left, {weeks_left} week left and {months_left} months left")



