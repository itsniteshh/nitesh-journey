#Write your code below this line 👇



name = input("What is your name?")
print(len(name))



