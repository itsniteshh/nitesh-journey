# 🚨 Don't change the code below 👇
age = input("What is your current age?")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
current_age = int(age)
remaining_age = 90 - current_age

days_left = remaining_age * 365
weeks_left = remaining_age * 52
months_left = remaining_age * 12

print(f"You have {days_left} days left, {weeks_left} weeks left and {months_left} months left.")



