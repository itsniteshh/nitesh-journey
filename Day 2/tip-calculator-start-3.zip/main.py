#If the bill was $150.00, split between 5 people, with 12% tip. 
bill_amt = int(input("Enter your total bill: \n"))
total_frnds = int(input("Enter number of frnds: \n"))
#Each person should pay (150.00 / 5) * 1.12 = 33.6
#Format the result to 2 decimal places = 33.60
contro = (bill_amt * 1.20) / total_frnds


#Tip: There are 2 ways to round a number. You might have to do some Googling to solve this.💪
print(f"Per person contribution is {round(contro)}.")