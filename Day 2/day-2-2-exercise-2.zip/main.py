# 🚨 Don't change the code below 👇
height = input("enter your height in m: ")
weight = input("enter your weight in kg: ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
bmi = float(weight) / (float(height) * float(height))


if bmi < 18.5:
  print("underwieght")
elif bmi < 25:
  print("normal weight")
elif bmi < 30:
  print("overweight")
else:
  print("obese")