from replit import clear
from art import logo


#HINT: You can call clear() to clear the output in the console.
def bid_storage(users_name, bid_amt):
  #func to check who's the highest bidder
  max_bid = 0
  max_bidder = ""
  bids = {}
  bids[users_name] = bid_amt

  for k, v in bids.items():
    if v > max_bid:
      max_bid = v
      max_bidder = k
  print(f"The max bidder is {max_bidder} with {max_bid} amount")
  
while True:
  print(logo)
  name = input("Enter your name:\n")
  bid_price = int(input("Enter a bidding price:\n"))

  another_try = input("are there any other users who want to try:\n")
  if another_try == "yes":
    bid_storage(name, bid_price)
    clear()
  else:
    bid_storage(name, bid_price)
    print("Thank You for playing our game")
    break
    
  
  