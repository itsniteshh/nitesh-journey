from art import logo

def calculator_program(number1, number2, operation=""):
  #function to work the calc program
  if operation == "+":
    total = num1 + num2
  elif operation == "-":
    total = num1 - num2
  elif operation == "*":
    total = num1 * num2
  elif operation == "/":
    total = num1 / num2
  return total

def num():
  print(logo)
  number1 = int(input("Enter first number?: "))
  return number1
num1 = num()  

while True:
  #loop to continuously ask user for inputs
  print("\n+\n-\n*\n/")
  op = input("Pick an operation: ")
  num2 = float(input("Enter another number?: "))
  
  total = calculator_program(num1, num2, op)
  print(f"{num1} {op} {num2} = {total}")

  another_try = input(f"Type 'y' to continue calculating using {total}, or type 'q' to quit:  ").lower()
  
  if another_try == "q":
    break
  elif another_try == "y":
    num1 = total