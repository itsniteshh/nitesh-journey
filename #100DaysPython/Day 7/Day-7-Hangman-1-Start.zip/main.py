#Step 1 
import random
word_list = ["aardvark", "baboon", "camel"]

#TODO-1 - Randomly choose a word from the word_list and assign it to a variable called chosen_word.
guessed_word = random.choice(word_list)
print(guessed_word)

#TODO-2 - Ask the user to guess a letter and assign their answer to a variable called guess. Make guess lowercase.
user_guess = input("Guess the letter:\n")
#TODO-3 - Check if the letter the user guessed (guess) is one of the letters in the chosen_word.
for words in guessed_word:
  if user_guess == words:
    print(f"{user_guess} is present")