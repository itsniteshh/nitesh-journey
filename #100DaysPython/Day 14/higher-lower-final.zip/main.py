from art import logo, vs
import random
from game_data import data
count = 0

def random_guesses(d):
  #function to randomly guess
  new_data = random.choice(data)
  return new_data

a = random_guesses(data)


def comparing_both(char1, char2):
  #function to compare within 2 datas
  forA = char1.get("follower_count")
  forB = char2.get("follower_count")
  

comparing_both(a, b)


while True:
  print(logo)
  if count > 0:
    print(f"You're right! Current score {count}")
    
  num1 = f"Compare A: {a.get("name")}, a {a.get("description")}, from {a.get("country")}."
  #checking to see if the user guesses correctly
                                                                     
  num2 = f"Compare B: {b.get("name")}, a {b.get("description")}, from {b.get("country")}."
  user_input = input("Who has more followers 'A' or 'B': ").lower()

  b = random_guesses(data)

#if correct guess, show score and make B into A

#repeating random guess