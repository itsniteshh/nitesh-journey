#Number Guessing Game Objectives:
import random
easy_mode = 5
hard_mode = 3
answer = random.randint(1, 100)

print("Welcome to the guessing game!")
print("I am thinking of a number between 1 and 100")
print(f"the correct answer is {answer}")
difficulty = input("choose a difficulty. Type 'easy' or 'hard': ")

def difficulty_mode(difficulty, easy, hard):
  

while True:
  guess_num = int(input("Make a guess: "))

  if guess_num > answer:
    print("Guess too high! try again")
    
  elif guess_num < answer:
    print("Guess too low! try again")
  
  else:
    print("You win")
    break

    
  if difficulty == "hard":
    print(f"You have {hard_mode} attempts remaining to guess the number.")
    hard_mode -= 1
    if hard_mode == 0:
      print("Out of guesses! You lose")
      break

  else:
    print(f"You have {easy_mode} attempts remaining to guess the number.")
    easy_mode -= 1
    if easy_mode == 0:
      print("Out of guesses! You lose")
      break

