#Write your code below this line 👇
#Hint: Remember to import the random module first. 🎲

import random

coins = random.randint(0,1)
if coins == 0:
  print("Heads")
else:
  print("Tails")








