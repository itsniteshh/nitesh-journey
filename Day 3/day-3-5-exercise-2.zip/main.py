# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n").lower()
name2 = input("What is their name? \n").lower()
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
both_name = name1 + name2

t = both_name.count("t")
r = both_name.count("r")
u = both_name.count("u")
e = both_name.count("e")

l = both_name.count("l")
o = both_name.count("o")
v = both_name.count("v")
e = both_name.count("e")

love1 = t + r + u + e
love2 = l + o + v + e
print(f"Your love score is {love1}{love2}")
