#Write your code below this line 👇

name = input("Enter your name? \n")
print(f"My name is {name}")
